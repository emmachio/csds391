Assignment 6 files:

Number 6:
The code required for number 6 can be found in the candyBags.py file.
I had originally worked to try and make it so that the inputs can be inputted from the terminal, however it proved difficult because it would not easily change the data type of strings into floats which was necessary in order for the code to function properly. Instead, I had made the inputs variables that can be changed inside of the py file at the very bottom. I left the default to be what the example for 6c so that at least something would pop up when the code was run, but feel free to change it to test out the code in other ways. 